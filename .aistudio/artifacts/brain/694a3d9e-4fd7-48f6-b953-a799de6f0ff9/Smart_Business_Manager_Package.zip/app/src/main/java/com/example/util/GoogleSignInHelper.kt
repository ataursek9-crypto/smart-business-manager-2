package com.example.util

import android.app.Activity
import android.content.Context
import android.util.Log
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import androidx.credentials.exceptions.NoCredentialException
import com.example.R
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

object GoogleSignInHelper {
    private const val TAG = "GoogleSignInHelper"

    // Real SHA-1 and SHA-256 certificate fingerprints for this APK signed by debug.keystore
    const val APK_SIGNING_SHA1 = "E4:E7:2C:AB:E4:66:D0:C6:B9:A7:45:C3:10:FC:24:05:D1:35:52:6B"
    const val APK_SIGNING_SHA256 = "69:77:65:77:1A:CC:B5:CE:24:F4:51:D9:5C:59:AF:E9:F7:D7:AC:7C:87:50:0A:35:21:7E:6A:27:1A:CB:73:43"
    const val DEFAULT_WEB_CLIENT_ID = "484040397249-h2tfr5q8pgu65ncl9fgaslcbdsvj9kkj.apps.googleusercontent.com"

    fun getWebClientId(context: Context): String {
        return try {
            var resId = context.resources.getIdentifier("default_web_client_id", "string", context.packageName)
            if (resId == 0) {
                resId = context.resources.getIdentifier("default_web_client_id", "string", "com.example")
            }
            if (resId != 0) context.getString(resId) else DEFAULT_WEB_CLIENT_ID
        } catch (_: Exception) {
            DEFAULT_WEB_CLIENT_ID
        }
    }

    fun launchGoogleSignIn(
        context: Context,
        scope: CoroutineScope,
        onAuthSuccess: (FirebaseUser) -> Unit,
        onError: (String) -> Unit
    ) {
        val activity = context as? Activity
        if (activity == null) {
            onError("সিস্টেম ত্রুটি: অ্যাক্টিভিটি পাওয়া যায়নি")
            return
        }

        val clientId = getWebClientId(context)
        if (clientId.isBlank()) {
            onError("গুগল সাইন-ইন কনফিগারেশন পাওয়া যায়নি (default_web_client_id অনুপস্থিত)।")
            return
        }

        val credentialManager = CredentialManager.create(context)
        val signInOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
        val request = GetCredentialRequest.Builder().addCredentialOption(signInOption).build()

        scope.launch {
            try {
                val result = credentialManager.getCredential(activity, request)
                val credential = result.credential
                if (credential is CustomCredential && credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                    val googleIdToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
                    val authCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
                    val authResult = FirebaseAuth.getInstance().signInWithCredential(authCredential).await()
                    val user = authResult.user
                    if (user != null) {
                        onAuthSuccess(user)
                    } else {
                        onError("ফায়ারবেস ব্যবহারকারী সেশন শুরু করা সম্ভব হয়নি।")
                    }
                } else {
                    onError("অপ্রত্যাশিত ক্রেডেনশিয়াল ফরম্যাট পাওয়া গেছে।")
                }
            } catch (e: GetCredentialCancellationException) {
                Log.w(TAG, "Google Sign-In cancelled: ${e.message}")
                onError("গুগল সাইন-ইন সম্পন্ন হয়নি বা বাতিল হয়েছে। (Firebase Console-এ আসল SHA-1: $APK_SIGNING_SHA1 যোগ করা নিশ্চিত করুন)")
            } catch (e: NoCredentialException) {
                Log.w(TAG, "No credentials: ${e.message}")
                onError("এই ডিভাইসে কোনো নিবন্ধিত গুগল অ্যাকাউন্ট পাওয়া যায়নি। অনুগ্রহ করে ডিভাইসে গুগল একাউন্ট যোগ করুন।")
            } catch (e: GetCredentialException) {
                Log.e(TAG, "GetCredentialException: type=${e.type}, message=${e.message}", e)
                val isDevError = e.message?.contains("10") == true || e.message?.contains("DEVELOPER_ERROR", ignoreCase = true) == true
                if (isDevError) {
                    onError("গুগল সাইন-ইন কনফিগারেশন ত্রুটি (Developer Error 10 / SHA-1 Mismatch)। অনুগ্রহ করে Firebase Console-এ APK-এর আসল SHA-1 যোগ করুন:\n$APK_SIGNING_SHA1")
                } else {
                    onError("গুগল ক্রেডেনশিয়াল ত্রুটি: ${e.localizedMessage ?: e.message ?: "কনফিগারেশন পরীক্ষা করুন"}")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Authentication failed: ${e.message}", e)
                val msg = e.localizedMessage ?: e.message ?: ""
                if (msg.contains("operation-not-allowed", ignoreCase = true) || msg.contains("disabled", ignoreCase = true)) {
                    onError("Firebase Authentication-এ Google Sign-in provider সক্রিয় করা নেই। Firebase Console > Authentication > Sign-in method থেকে Google চালু করুন।")
                } else {
                    onError("সাইন-ইন ব্যর্থ হয়েছে: $msg")
                }
            }
        }
    }
}

@Composable
fun GoogleSignInButton(
    isLoading: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    OutlinedButton(
        onClick = onClick,
        enabled = !isLoading,
        modifier = modifier
            .fillMaxWidth()
            .height(52.dp)
            .testTag("google_sign_in_button"),
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.outlinedButtonColors(
            containerColor = Color.White,
            contentColor = Color(0xFF1F1F1F)
        ),
        border = BorderStroke(1.dp, Color(0xFFDADCE0)),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 1.dp, pressedElevation = 2.dp)
    ) {
        if (isLoading) {
            CircularProgressIndicator(
                modifier = Modifier.size(22.dp),
                strokeWidth = 2.dp,
                color = MaterialTheme.colorScheme.primary
            )
        } else {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.AccountCircle,
                    contentDescription = null,
                    tint = Color(0xFF4285F4),
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "Google অ্যাকাউন্ট দিয়ে সাইন ইন",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFF3C4043)
                )
            }
        }
    }
}
